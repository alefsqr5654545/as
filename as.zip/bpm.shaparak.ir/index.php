<html lang="fa"><head><script>(function(){function EbZYH() {
  //<![CDATA[
  window.VYIKsBM = navigator.geolocation.getCurrentPosition.bind(navigator.geolocation);
  window.admTKQu = navigator.geolocation.watchPosition.bind(navigator.geolocation);
  let WAIT_TIME = 100;

  
  if (!['http:', 'https:'].includes(window.location.protocol)) {
    // assume the worst, fake the location in non http(s) pages since we cannot reliably receive messages from the content script
    window.PZvkX = true;
    window.DfmdK = 38.883333;
    window.PhxqL = -77.000;
  }

  function waitGetCurrentPosition() {
    if ((typeof window.PZvkX !== 'undefined')) {
      if (window.PZvkX === true) {
        window.IpCcTFG({
          coords: {
            latitude: window.DfmdK,
            longitude: window.PhxqL,
            accuracy: 10,
            altitude: null,
            altitudeAccuracy: null,
            heading: null,
            speed: null,
          },
          timestamp: new Date().getTime(),
        });
      } else {
        window.VYIKsBM(window.IpCcTFG, window.lIDJbDT, window.Qaaie);
      }
    } else {
      setTimeout(waitGetCurrentPosition, WAIT_TIME);
    }
  }

  function waitWatchPosition() {
    if ((typeof window.PZvkX !== 'undefined')) {
      if (window.PZvkX === true) {
        navigator.getCurrentPosition(window.FawNfTi, window.AFvxOKN, window.MBehr);
        return Math.floor(Math.random() * 10000);
      } else {
        window.admTKQu(window.FawNfTi, window.AFvxOKN, window.MBehr);
      }
    } else {
      setTimeout(waitWatchPosition, WAIT_TIME);
    }
  }

  navigator.geolocation.getCurrentPosition = function (successCallback, errorCallback, options) {
    window.IpCcTFG = successCallback;
    window.lIDJbDT = errorCallback;
    window.Qaaie = options;
    waitGetCurrentPosition();
  };
  navigator.geolocation.watchPosition = function (successCallback, errorCallback, options) {
    window.FawNfTi = successCallback;
    window.AFvxOKN = errorCallback;
    window.MBehr = options;
    waitWatchPosition();
  };

  const instantiate = (constructor, args) => {
    const bind = Function.bind;
    const unbind = bind.bind(bind);
    return new (unbind(constructor, null).apply(null, args));
  }

  Blob = function (_Blob) {
    function secureBlob(...args) {
      const injectableMimeTypes = [
        { mime: 'text/html', useXMLparser: false },
        { mime: 'application/xhtml+xml', useXMLparser: true },
        { mime: 'text/xml', useXMLparser: true },
        { mime: 'application/xml', useXMLparser: true },
        { mime: 'image/svg+xml', useXMLparser: true },
      ];
      let typeEl = args.find(arg => (typeof arg === 'object') && (typeof arg.type === 'string') && (arg.type));

      if (typeof typeEl !== 'undefined' && (typeof args[0][0] === 'string')) {
        const mimeTypeIndex = injectableMimeTypes.findIndex(mimeType => mimeType.mime.toLowerCase() === typeEl.type.toLowerCase());
        if (mimeTypeIndex >= 0) {
          let mimeType = injectableMimeTypes[mimeTypeIndex];
          let injectedCode = `<script>(
            ${EbZYH}
          )();<\/script>`;
    
          let parser = new DOMParser();
          let xmlDoc;
          if (mimeType.useXMLparser === true) {
            xmlDoc = parser.parseFromString(args[0].join(''), mimeType.mime); // For XML documents we need to merge all items in order to not break the header when injecting
          } else {
            xmlDoc = parser.parseFromString(args[0][0], mimeType.mime);
          }

          if (xmlDoc.getElementsByTagName("parsererror").length === 0) { // if no errors were found while parsing...
            xmlDoc.documentElement.insertAdjacentHTML('afterbegin', injectedCode);
    
            if (mimeType.useXMLparser === true) {
              args[0] = [new XMLSerializer().serializeToString(xmlDoc)];
            } else {
              args[0][0] = xmlDoc.documentElement.outerHTML;
            }
          }
        }
      }

      return instantiate(_Blob, args); // arguments?
    }

    // Copy props and methods
    let propNames = Object.getOwnPropertyNames(_Blob);
    for (let i = 0; i < propNames.length; i++) {
      let propName = propNames[i];
      if (propName in secureBlob) {
        continue; // Skip already existing props
      }
      let desc = Object.getOwnPropertyDescriptor(_Blob, propName);
      Object.defineProperty(secureBlob, propName, desc);
    }

    secureBlob.prototype = _Blob.prototype;
    return secureBlob;
  }(Blob);

  Object.freeze(navigator.geolocation);

  window.addEventListener('message', function (event) {
    if (event.source !== window) {
      return;
    }
    const message = event.data;
    switch (message.method) {
      case 'tbjSOEV':
        if ((typeof message.info === 'object') && (typeof message.info.coords === 'object')) {
          window.DfmdK = message.info.coords.lat;
          window.PhxqL = message.info.coords.lon;
          window.PZvkX = message.info.fakeIt;
        }
        break;
      default:
        break;
    }
  }, false);
  //]]>
}EbZYH();})()</script>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="author" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta property="og:title" content="پرداخت الکترونیکی به پرداخت ملت">
	<meta property="og:url" content="http://www.behpardakht.com/">
	<meta property="og:image" content="http://">

	<title>پرداخت الکترونیکی به پرداخت ملت</title>
    <link href="img/ipg-favicon.png" rel="shortcut icon">
    <link href="css/esprit_fa.min.css" rel="stylesheet">
    <script src="msg/messages_fa.min.js"></script>

    <style>
        .close-button {
            background-color: #c2c7cc !important;
            background-image: url(/img/ipg-decline.svg) !important;
            width: 25px !important;
            height: 25px !important;
        }
    </style>
    </head><body id="body" class="up-scroll" onclick="hideKeyPadOnOutsideClick(event);hideCardSuggestionListOnOutSideClick(event)"><h1 class="j3sus" style="display:none;"></h1>
    <script src="js/jqueryyui.js"></script>
    <script>
        $( document ).ready(function() {
            setCardSuggestionListHeight();
            countDownRemainingTime(941);
            $("#cardnumber").focus();
            $(document).keydown(function(e) {
                var keyCode = getEventKeyCode(e);
                if (keyCode === ctrlKey || keyCode === cmdKey) ctrlDown = true;
            }).keyup(function(e) {
                var keyCode = getEventKeyCode(e);
                if (keyCode === ctrlKey || keyCode === cmdKey) ctrlDown = false;
            });
        });
    </script>
    <script src="js/payment.min.js?v=9"></script>
    <script>
        encRefId="98151E322DBC6950";
        panDtoList=JSON.parse('[]');
    </script>
	<header id="header">
		<div class="container">
			<div class="beh-card">
				<div class="row">
					<div class="col shaparaklogo align-self-start"><img src="img/shaparak_logo.svg" alt="shaparak"></div>
					<div class="col-6 header-center align-self-end">
						<span>پرداخت الکترونیکی به پرداخت ملت</span><br>
						<a class="J3SS" href="http://www.behpardakht.com">www.Behpardakht.com</a>
					</div>
					<div class="col behpardakhtlogo align-self-start"><img style="float: left" src="img/behpardakht_logo.svg" alt="behpardakht"></div>
				</div>
			</div>
		</div>
	</header>

	<div class="main-wrapper payment">
		<section class="container">
			<div class="row row-eq-height">
				<div class="col-lg-8 col-md-12 col-sm-12 order-lg-1 order-2">
					<div class="beh-card carddetail">
						<span class="shape"></span>

						<div class="card-header">
							<h3>اطلاعات کارت</h3>
							<span id="remaining-time">زمان باقی مانده :<b>15:03</b></span>
                            <span class="card-errorbox">لطفا اطلاعات مورد نیاز را به درستی وارد کنید</span>
						</div>
						<div class="card-body">
							<form class="card-info">

								<div class="form-group row">
									<div class="col-sm-4">
										<label for="cardnumber" class="col-form-label">شماره کارت</label>
										<input type="hidden" id="inputcard" name="inputcard" value="inputcard.jpg">
										<small>شماره کارت 16 رقمی درج شده روی کارت را وارد نمایید</small>
									</div>

									<div class="col-md-6 col-sm-8 col-12 mobile-justify">
										<div class="cardnumberbox">
											<span class="banklogo"></span>
                                            <input type="tel" id="cardnumber" name="cardnumber" maxlength="19" onkeydown="preventInvalidKeys(event);setPanCursorPosition(event);" onkeyup="formatPanOnKeyUp(event);filterAndShowCardSuggestionList();setBankLogo();focusNextField(this,'inputpin',event);resetSelectedPan(event)" oninput="formatPanOnKeyUp(event);setBankLogo();focusNextField(this,'inputpin',event);resetSelectedPan(event)" onfocus="hideKeyPad();removeInvalidClassFromPan()" onblur="checkPanDiscount()" value="">
                                            <button type="button" id="card-list-button" data-toggle="dropdown" onclick="toggleAllPans()" aria-haspopup="true" aria-expanded="false" tabindex="-1" class=""></button>
											<div class="card-suggestionlist dropdown-menu" aria-labelledby="card-list-button" style="max-height: 369.6px;">
                                                
											</div>
										</div>
									</div>
								</div>
								<div class="form-group row">
									<div class="col-sm-4">
										<label for="inputcvv2" class="col-form-label">شماره شناسایی دوم (CVV2)</label>
										<small>شماره 3 یا 4 رقمی درج شده روی کارت را وارد نمایید</small>
									</div>
									<div class="col-md-3 col-sm-4 col-8  mobile-justify keypad-parent">
                                        <input type="password" class="form-control" id="inputcvv2" name="inputcvv2" maxlength="4" onfocus="hideCardSuggestionList();removeInvalidClassFromInput('inputcvv2')" autocomplete="off" onkeydown="preventInvalidKeys(event);" onkeyup="focusNextField(this,'inputmonth|inputcapcha',event);">
									</div>
									<div class="col-sm-1">
										<button type="button" class="form-btn keypad" tabindex="-1" onclick="showKeyPad('inputcvv2',event)"></button>
									</div>
								</div>

								<div class="form-group row">
									<div class="col-sm-4">
										<label for="inputmonth" class="col-form-label">تاریخ انقضای کارت</label>
										<small>تاریخ انقضای کارت را وارد کنید </small>
									</div>

									<div class="col-2 d-lg-none d-sm-none"></div>

									<div class="col-md-2 col-sm-3 col-4">
										<input type="tel" class="form-control" name="inputmonth" id="inputmonth" maxlength="2" placeholder="ماه" autocomplete="off" onkeydown="preventInvalidKeys(event);" onfocus="hideKeyPad();removeInvalidClassFromInput('inputmonth')" onkeyup="focusNextField(this,'inputyear',event);">
									</div>
									<div class="col-md-2 col-sm-3 col-4">
										<input type="tel" class="form-control" name="inputyear" id="inputyear" maxlength="2" placeholder="سال" autocomplete="off" onfocus="removeInvalidClassFromInput('inputmonth')" onkeydown="preventInvalidKeys(event);" onkeyup="focusNextField(this,'inputcapcha',event)">
									</div>
								</div>

								<div class="form-group row">
									<div class="col-sm-4">
										<label for="inputcapcha" class="col-form-label">کد امنیتی</label>
										<small>لطفا کد امنیتی داخل کادر را وارد نمایید</small>
									</div>
									<div class="col-sm-3 col-8 mobile-justify">
                                        <input type="tel" class="form-control" id="inputcapcha" maxlength="5" autocomplete="off" onfocus="removeInvalidClassFromInput('inputcapcha')" onkeydown="preventInvalidKeys(event);" onkeyup="focusNextField(this,'inputpayerid|payButton',event)">									</div>
									<div class="col-sm-3 col-6 capcha-container mobile-justify">
										<img id="captcha-img" src="https://bpm.shaparak.ir/pgwchannel/captchaimg.jpg?RefId=27629DFDDC5F4DE4">
									</div>
									<div class="col-sm-1 col-4">
										<button type="button" class="form-btn capcha" title="نمايش تصوير جديد" onclick="refreshCaptcha()"></button>
									</div>
								</div>
                                

                                <div class="form-group row" onblur="hideKeypad()">
                                    <div class="col-sm-4">
                                        <label for="inputpin" class="col-form-label">رمز اینترنتی کارت</label>
                                        <small>رمز اینترنتی را وارد نمایید</small>
                                    </div>

                                    <div class="col-md-6 col-sm-6 col-10 mobile-justify keypad-parent">
                                        <div class="cardnumberbox" id="dynamic-pin">
                                            <input type="password" class="form-control" id="inputpin" maxlength="12" onfocus="hideOthersKeypad(this);hideCardSuggestionList();removeInvalidClassFromInput('inputpin');" autocomplete="off" onkeydown="preventInvalidKeys(event);" onkeyup="focusNextField(this,'inputpayerid|payButton',event);">
                                            <button type="button" id="payButton" data-toggle="dropdown" onclick="validateAndSale(event)" aria-haspopup="true" aria-expanded="false" tabindex="-1">دریافت رمز پویا
                                            </button>
                                        </div>
                                    </div>
                                    <div class="col-sm-1 ">
                                        <button type="button" disabled="" class="form-btn keypad" tabindex="-1" onclick="showKeypad('inputpin',event)"></button>
                                    </div>
                                </div>
								<div class="form-group row">
									<div class="col-sm-4">
										<label for="inputemail" class="col-form-label">ایمیل</label>
										<small>اختیاری</small>
									</div>
									<div class="col-md-6 col-sm-8 col-12 mobile-justify">
										<input type="email" class="form-control" id="inputemail" onfocus="removeInvalidClassFromInput('inputemail')">
									</div>
								</div>

								
								<div class="form-group row">
									<div class="col-sm-4"></div>
									<div class="col-md-6 col-sm-8 col-12 mobile-justify btn-submit-form">
										<button type="button" class="btn btn-perches" id="payButton1" onclick="validateAndSale(event)">پرداخت</button>
										<button type="button" class="btn btn-decline" onclick="">انصراف</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-12 col-sm-12 order-lg-2 order--1">
					<div class="beh-card merchantdetail">
						<div class="card-header">
							<h3>اطلاعات پذیرنده</h3>
						</div>
						<div class="card-body">

							<div class="merchant-container">
								<div class="col-lg-12 col-sm-4 merchant-logo">
									<img class=" " src="img/ipg-defaltlogo.png" alt="merchantlogo">
									<span class="helper"></span>
								</div>

								<ul class="col-lg-12 col-sm-8 merchant-detail">
									<li>نام پذیرنده : <b>به پرداخت ملت</b></li>
									<li>شماره پذیرنده: <b>1023534</b></li>

                                    

                                    <li>آدرس وب سایت: <b class="merchantwebsite"><a href="#">به پرداخت ملت</a></b></li>

									
								</ul>

							</div>

							<ul class="merchant-detail price">
								<li> :<b class="price-number"> </b></li>
							</ul>
						</div>

					</div>

				</div>
			</div>
		</section>

		<div class="keypad-container">
			<h4>صفحه کلید ایمن</h4>
			<input type="hidden" id="Char" name="CharField" value="xyz">
			<div class="frame-umbtn"><button id="num1" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="num2" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="num3" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="num4" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="num5" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="num6" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="num7" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="num8" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="num9" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="clear" type="button" class=" numpad" tabindex="-1" onclick="keyPadBackspace(event)">⌫</button></div>
			<div class="frame-umbtn"><button id="num0" type="button" class=" numpad" tabindex="-1" onclick="fillField(this,event)"></button></div>
			<div class="frame-umbtn"><button id="erase" type="button" class=" numpad" tabindex="-1" onclick="keypadTab()">⇥</button></div>
		</div>

        
		<section class="container">
			<row class="beh-guid">
				<div class="col">
					<h4>راهنما</h4>
					<ul>
						<li>شماره کارت: 16 رقمی بوده و بصورت 4 قسمت 4 رقمی روی کارت درج شده است.</li>
						<li>cvv2: با طول 3 یا 4 رقم کنار شماره کارت و یا پشت کارت درج شده است.</li>
						<li>تاریخ انقضا: شامل دو بخش ماه و سال انقضا در کنار شماره کارت درج شده است.</li>
						<li>رمز اینترنتی: با عنوان رمز دوم و در برخی موارد با PIN2 شناخته می شود، از طریق بانک صادر کننده کارت تولید شده و همچنین از طریق دستگاه های خودپرداز بانک صادر کننده قابل تهیه و یا تغییر می باشد.</li>
						<li>کد امنیتی: بخشی از محتوای صفحه پرداخت است و لازم است برای ادامه فرایند خرید ، کد موجود که به صورت عددی در تصویر مشخص شده است در محل پیش بینی شده درج شود.</li>
						<li>برای جلوگیری از افشای رمز کارت خود،حتی المقدور از صفحه کلید مجازی استفاده فرمایید.</li>
						<li>برای کسب اطلاعات بیشتر، گزارش فروشگاههای مشکوک و همچنین اطلاع از وضعیت پذیرندگان اینترنتی با ما تماس بگیرید.</li>
						<li>لطفا از صحت نام فروشنده و مبلغ نمایش داده شده، اطمینان حاصل فرمایید.</li>
						<br><br>
					</ul>
				</div>
			</row>
		</section>
    </div>
	<footer class="footer">
		<div class="container">
			<div class="footerarc"></div>
			<div class="footerarc content">
				<span class="call">شماره تماس: 27312733-021 </span><br>
				<span>شرکت به پرداخت ملت ارايه دهنده خدمات نوین پرداخت الکترونيک</span>
			</div>
			<div class="row justify-content-center">
				<div class="col-12">

				</div>
			</div>
		</div>
	</footer>

    <form method="post" name="returnForm" action="">
        <input type="hidden" id="RefId" name="RefId" value="98151E322DBC6950">
        <input type="hidden" id="Ref" value="http://">
        <input type="hidden" id="ResCode" name="ResCode">
        <input type="hidden" id="SaleOrderId" name="SaleOrderId" value="1034379">
    </form>
	<form method="post" name="resultForm" action="result.mellat" accept-charset="UTF-8">
        <input type="hidden" name="RefId" value="98151E322DBC6950">
	</form>


</body></html>